package com.example.cs2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
